package com.example.student1;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {

    private final ObservableList<Student> studentData = FXCollections.observableArrayList();

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Student Percentage Calculator");

        // Form elements
        Label firstNameLabel = new Label("First Name:");
        TextField firstNameField = new TextField();

        Label lastNameLabel = new Label("Last Name:");
        TextField lastNameField = new TextField();

        Label calculatedMarksLabel = new Label("Calculated Marks:");
        TextField calculatedMarksField = new TextField();

        Label totalMarksLabel = new Label("Total Marks:");
        TextField totalMarksField = new TextField();

        Button addButton = new Button("Add Student");

        // Form layout
        GridPane formGrid = new GridPane();
        formGrid.setPadding(new Insets(10));
        formGrid.setHgap(10);
        formGrid.setVgap(10);

        formGrid.add(firstNameLabel, 0, 0);
        formGrid.add(firstNameField, 1, 0);
        formGrid.add(lastNameLabel, 0, 1);
        formGrid.add(lastNameField, 1, 1);
        formGrid.add(calculatedMarksLabel, 0, 2);
        formGrid.add(calculatedMarksField, 1, 2);
        formGrid.add(totalMarksLabel, 0, 3);
        formGrid.add(totalMarksField, 1, 3);
        formGrid.add(addButton, 1, 4);

        // Table to display student data
        TableView<Student> studentTable = new TableView<>();
        studentTable.setEditable(true);

        TableColumn<Student, String> fullNameColumn = new TableColumn<>("Full Name");
        fullNameColumn.setCellValueFactory(cellData -> cellData.getValue().fullNameProperty());

        TableColumn<Student, Integer> calculatedMarksColumn = new TableColumn<>("Calculated Marks");
        calculatedMarksColumn.setCellValueFactory(cellData -> cellData.getValue().calculatedMarksProperty().asObject());

        TableColumn<Student, Integer> totalMarksColumn = new TableColumn<>("Total Marks");
        totalMarksColumn.setCellValueFactory(cellData -> cellData.getValue().totalMarksProperty().asObject());

        TableColumn<Student, Double> percentageColumn = new TableColumn<>("Student Percentage");
        percentageColumn.setCellValueFactory(cellData -> cellData.getValue().percentageProperty().asObject());

        studentTable.setItems(studentData);
        studentTable.getColumns().addAll(fullNameColumn, calculatedMarksColumn, totalMarksColumn, percentageColumn);

        // Delete button
        Button deleteButton = new Button("Delete Student");
        deleteButton.setOnAction(e -> {
            Student selectedStudent = studentTable.getSelectionModel().getSelectedItem();
            studentData.remove(selectedStudent);
        });

        HBox tableControls = new HBox(10, deleteButton);
        VBox tableContainer = new VBox(10, studentTable, tableControls);

        // Main layout
        VBox mainLayout = new VBox(10, formGrid, tableContainer);
        mainLayout.setPadding(new Insets(10));

        // Add student button action
        addButton.setOnAction(e -> {
            try {
                String firstName = firstNameField.getText();
                String lastName = lastNameField.getText();
                int calculatedMarks = Integer.parseInt(calculatedMarksField.getText());
                int totalMarks = Integer.parseInt(totalMarksField.getText());

                if (calculatedMarks < 0 || calculatedMarks > 500 || totalMarks != 500) {
                    throw new IllegalArgumentException("Invalid data entered.");
                }

                double percentage = (double) calculatedMarks / totalMarks * 100;

                Student student = new Student(firstName, lastName, calculatedMarks, totalMarks, percentage);
                studentData.add(student);

                firstNameField.clear();
                lastNameField.clear();
                calculatedMarksField.clear();
                totalMarksField.clear();

            } catch (IllegalArgumentException ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR, ex.getMessage());
                alert.showAndWait();
            }
        });

        Scene scene = new Scene(mainLayout, 600, 400);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
