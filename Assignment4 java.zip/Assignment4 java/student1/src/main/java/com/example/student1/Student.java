package com.example.student1;
import javafx.beans.property.*;

public class Student {
    private final StringProperty firstName;
    private final StringProperty lastName;
    private final IntegerProperty calculatedMarks;
    private final IntegerProperty totalMarks;
    private final DoubleProperty percentage;

    public Student(String firstName, String lastName, int calculatedMarks, int totalMarks, double percentage) {
        this.firstName = new SimpleStringProperty(firstName + " " + lastName);
        this.lastName = new SimpleStringProperty(lastName);
        this.calculatedMarks = new SimpleIntegerProperty(calculatedMarks);
        this.totalMarks = new SimpleIntegerProperty(totalMarks);
        this.percentage = new SimpleDoubleProperty(percentage);
    }

    public StringProperty fullNameProperty() {
        return firstName;
    }

    public StringProperty lastNameProperty() {
        return lastName;
    }

    public IntegerProperty calculatedMarksProperty() {
        return calculatedMarks;
    }

    public IntegerProperty totalMarksProperty() {
        return totalMarks;
    }

    public DoubleProperty percentageProperty() {
        return percentage;
    }
}
